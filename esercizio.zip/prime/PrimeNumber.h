#include<iostream>
using namespace std;
class PrimeNumber {
    int number;
public:
    PrimeNumber(int x);
    bool isPrime();
};